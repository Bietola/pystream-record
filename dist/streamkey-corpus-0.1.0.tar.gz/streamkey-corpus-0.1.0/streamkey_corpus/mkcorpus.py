import fire

import process_raw
import record_kps

def cli():
    fire.Fire({
        'process-raw': process_raw.process,
        'record-kps': record_kps
    })
