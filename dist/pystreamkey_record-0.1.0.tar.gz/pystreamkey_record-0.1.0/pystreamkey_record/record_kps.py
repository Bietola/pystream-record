import keyboard
import time
from pathlib import Path

def save_key_press(f):
    def key_press(key):
        print(key.name)
        print(key.name, file=f)

    return key_press

def record_kps(target_file_path):
    with open(target_file, 'w') as f:
        keyboard.on_press(save_key_press(f))

        while True:
            time.sleep(1)

def cli():
    fire.Fire(record_kps)
